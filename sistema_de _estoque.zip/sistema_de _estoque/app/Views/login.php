<html>
<head>
<meta charset="utf-8">
<title>sistema de biblioteca - mjailton</title>
<link href="css/reset.css" rel="stylesheet" type="text/css">
<link href="css/estilo.css" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">

<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>
</head>

<body>
<div class="base-login">

	<div class="conteudo">
		<div class="caixa-login">
			<div class="imglogin">
				<img src="imagens/logo-login.png">
				<p>ENTRE COM SEU LOGIN E SENHA</p>
			</div>
			<form action="index.php?link=1" method="POST" name="">
				
				<input type="text" placeholder="login">
				
				<input type="password" placeholder="senha">
				<input type="submit" value="entrar" class="btn">
			</form>
		</div>
	</div>
</div>
</body>
</html>
