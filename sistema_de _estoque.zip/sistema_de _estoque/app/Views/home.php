<div class="conteudo">	
		<div class="caixa-home">
			<div class="base-relatorio-home">
				<div class="r-disponiveis">
					<h3>RELATÓRIOS DISPONÍVEIS</h3>
					<section>
						<article>
							<h2>PRODUTOS CADASTRADOS</h2>
							<span>160</span>
							<small>TOTAL DE PRODUTOS CADASTRADOS</small>
						</article>
						<article>
							<h2>VALOR ATUAL DO ESTOQUE</h2>
							<span>5.260,55</span>
							<small>VALOR DE TODOS OS PRODUTOS</small>
						</article>
						<article>
							<h2>PREÇO MÉDIO</h2>
							<span>50,00</span>
							<small>TOTAL DE PRODUTOS CADASTRADOS</small>
						</article>
						<article>
							<h2>VERSÃO DA PLANILHA</h2>
							<span>1.6.0</span>
							<small>VER MELHORIAS</small>
						</article>
					</section>
				</div>
				
				<div class="r-promemas">
					<h3>PROBLEMAS DETECTADOS</h3>
					<section>
						<article>
							<h2>INTENS COM ESTOQUE ALTO</h2>
							<span>16</span>
							<small>TPRODUTOS EM EXESSO</small>
						</article>
						<article>
							<h2>PRODUTOS SEM SAÍDA</h2>
							<span>5</span>
							<small>MOVIMENTAÇÃO RUIM</small>
						</article>
						<article>
							<h2>ITENS COM ESTOQUE BAIXO</h2>
							<span>2</span>
							<small>MARCADOS COMO - COMPRAR AGORA</small>
						</article>
						<article>
							<h2>itens fora da validade</h2>
							<span>40</span>
							<small>Produtos fora da validade</small>
						</article>
					</section>
				</div>
			</div>
		</div>
</div>
	