<html>
<head>
<meta charset="utf-8">
<title>Controle de estoque - mjailton</title>
<link href="css/reset.css" rel="stylesheet" type="text/css">
<link href="css/estilo.css" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<body>
	<div class="base-topo">
		<div class="conteudo">	
			<a href="index.php?link=1" class="logo"><img src="imagens/logo.png" title="logomarca"></a>		
	
		<div class="base-menu-topo">
		
			<div  class="menu">
				<ul>
					<li><a href="index.php?link=1"><i class="icone icone01"></i>home</a></li>
					
					<li><a href=""><i class="icone icone02"></i>Cadastros</a>
						<ul>
							<li><a href="index.php?link=2">cliente</a></li>
							<li><a href="index.php?link=4">produto</a>								
							</li>
							<li><a href="">Fornecedor</a></li>
						</ul>
					</li>
					
					<li class="n-arow"><a href=""><i class="icone icone03"></i>estoque</a>
						<ul>
							<li><a href="index.php?link=5">Entrada de produtos</a></li>
							<li><a href="">Saída de produtos</a></li>
							<li><a href="">movimentação em geral</a></li>
							
						</ul>
					</li>
					<li class="n-arow"><a href="index.php?link=3"><i class="icone icone04"></i>vendas</a>
						
					</li>
					<li><a href="ajuda.html"><i class="icone icone05"></i>sair</a></li>
					
				</ul>	
		
		</div>
	</div>
</div>
</div>

	<?php
			 
				@$link = $_GET["link"];
							
				$pag[1] = "home.php";
				$pag[2] = "lista-cliente.php";
				$pag[3] = "venda.php";
				$pag[4] = "lista-produto.php";
				$pag[5] = "entrada.php";
				$pag[6] = "form-cliente.php";
						
								
				
				if (!empty($link))
				{
					
					if (file_exists($pag[$link]))
					{
						
						include $pag[$link];
					}
					else
					{						
						
						include "home.php";
					}
				}
				else
				{					
					include "home.php";
				}			
			
			?>
	
</body>
</html>
