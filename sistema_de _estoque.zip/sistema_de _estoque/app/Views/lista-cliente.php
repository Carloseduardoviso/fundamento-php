	<div class="conteudo">
	<div class="base-geral">
	<h1 class="titulo"><span>cliente</span></h1>
		<div class="base-home">
			
			<div class="base-lista">
				<form action="" method="">
					<div class="formback">
						<div class="caixa01">
							<a href="index.php?link=6" class="btn">Adicionar novo cliente</a>
						</div>
						<div class="caixa02">
							
							<input type="text" name="" placeholder="Pesquisar">
							<input type="submit" value="ir" class="btn">
						</div>
						
						
					</div>
				</form>
			</div>
			
			<div class="base-lista">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				  <thead>
					  <tr>
						<th width="2%" align="left">Id</th>
						<th width="34%" align="center">Cliente</th>
						<th width="23%" align="center">Email</th>
						<th width="21%" align="center">fone</th>
						<th width="20%" align="center">Ação</th>
					  </tr>
				  </thead>
				  <tbody>
					  <tr>
						<td align="left">1</td>
						<td align="left">Gidalto goes dos santos</td>
						<td align="left">gidalto.goes8@gmail.com</td>
						<td align="center">(98) 9 81526066</td>
						<td align="center"><a href="" class="btn alterar">ALTERAR</a><a href="" class="btn excluir">excluir</a></td>
					  </tr>
					  
					  <tr>
						<td align="left">1</td>
						<td align="left">Gidalto goes dos santos</td>
						<td align="center">gidalto.goes8@gmail.com</td>
						<td align="center">(98) 9 81526066</td>
						<td align="center"><a href="" class="btn alterar">ALTERAR</a><a href="" class="btn excluir">excluir</a></td>
					  </tr>
					  
					  <tr>
						<td align="left">1</td>
						<td align="left">Gidalto goes dos santos</td>
						<td align="center">gidalto.goes8@gmail.com</td>
						<td align="center">(98) 9 81526066</td>
						<td align="center"><a href="" class="btn alterar">ALTERAR</a><a href="" class="btn excluir">excluir</a></td>
					  </tr>
					  
					  <tr>
						<td align="left">1</td>
						<td align="left">Gidalto goes dos santos</td>
						<td align="center">gidalto.goes8@gmail.com</td>
						<td align="center">(98) 9 81526066</td>
						<td align="center"><a href="" class="btn alterar">ALTERAR</a><a href="" class="btn excluir">excluir</a></td>
					  </tr>
					  
				  </tbody>
				</table>
			</div>
			<div class="base-pag">
				<p>Mostrando de 1 até 10 de 26 registros</p>
				<ul class="paginacao">
					<li><a href="" class="anterior">Anterior</a></li>
					<li><a href="">1</a></li>
					<li><a href="">2</a></li>
					<li><a href="">3</a></li>
					<li><a href="">[...]</a></li>
					<li><a href="" class="proximo">Próximo</a></li>
				</ul>
		</div>
		</div>
	</div>
</div>

