	<div class="conteudo">
	<div class="base-geral">
	<h1 class="titulo"><span>Entrada</span></h1>
		<div class="base-home">
			<div class="base-form">
					<div class="marcacao">
							<h3>Itens da venda</h3>
							<div class="coluna1">
								<input type="text" value="" name="" placeholder="Código">
							</div>
							<div class="coluna2">
								<input type="text" value="" name="" placeholder="Produto">
							</div>
							<div class="coluna3">
								<input type="text" value="" name="" placeholder="Qtde">
							</div>
							<div class="coluna3">
								<input type="submit" class="btn" value="Salvar" name="">
							</div>
							<div class="coluna4">
								<input type="text" placeholder="Pesquisa">
								<input type="submit" class="btn" value="ir">
							</div>
					</div>
			</div>
			
			<div class="base-lista">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				  <thead>
					  <tr>
						<th width="2%" align="left">Id</th>
						<th width="34%" align="center">Data</th>
						<th width="23%" align="center">Produto</th>
						<th width="21%" align="center">Quantidade</th>
					  </tr>
				  </thead>
				  <tbody>
					  <tr>
						<td align="left">1</td>
						<td align="center">2016-09-26</td>
						<td align="center">Mais um produto para teste</td>
						<td align="center">15</td>
						
					  </tr>
					  <tr>
						<td align="left">1</td>
						<td align="center">2016-09-26</td>
						<td align="center">Mais um produto para teste</td>
						<td align="center">15</td>
						
					  </tr>
					  <tr>
						<td align="left">1</td>
						<td align="center">2016-09-26</td>
						<td align="center">Mais um produto para teste</td>
						<td align="center">15</td>
						
					  </tr>
				  </tbody>
				</table>
			</div>
			<div class="base-pag">
				<p>Mostrando de 1 até 10 de 26 registros</p>
				<ul class="paginacao">
					<li><a href="" class="anterior">Anterior</a></li>
					<li><a href="">1</a></li>
					<li><a href="">2</a></li>
					<li><a href="">3</a></li>
					<li><a href="">[...]</a></li>
					<li><a href="" class="proximo">Próximo</a></li>
				</ul>
		</div>
		</div>
	</div>
</div>

