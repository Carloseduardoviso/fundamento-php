	<div class="conteudo">
	<div class="base-geral">
	<h1 class="titulo"><span>Produtos</span></h1>
		<div class="base-home">
			
			<div class="base-lista">
				<form action="" method="">
					<div class="formback">
						<div class="caixa01">
							<a href="" class="btn">Adicionar novo produto</a>
						</div>
						<div class="caixa02">
							
							<input type="text" name="" placeholder="Pesquisar">
							<input type="submit" value="ir" class="btn">
						</div>
						
						
					</div>
				</form>
			</div>
			
			<div class="base-lista">
			<table width="100%" border="0" cellspacing="0" cellpadding="0">
				  <thead>
					  <tr>
						<th width="2%" align="left">Id</th>
						<th width="34%" align="center">Produto</th>
						<th width="23%" align="center">Estoque</th>
						<th width="21%" align="center">Ativo</th>
						<th width="20%" align="center">Ação</th>
					  </tr>
				  </thead>
				  <tbody>
					  <tr>
						<td align="left">1</td>
						<td align="left">Primeiro Produto</td>
						<td align="center">101</td>
						<td align="center"><i class="ativo"></i>sim</td>
						<td align="center"><a href="" class="btn alterar">ALTERAR</a><a href="" class="btn excluir">excluir</a></td>
					  </tr>
					  <tr>
						<td align="left">2</td>
						<td align="left">Primeiro Produto</td>
						<td align="center">101</td>
						<td align="center"><i class="ativo"></i>sim</td>
						<td align="center"><a href="" class="btn alterar">ALTERAR</a><a href="" class="btn excluir">excluir</a></td>
					  </tr>
					  
					  <tr>
						<td align="left">3</td>
						<td align="left">Primeiro Produto</td>
						<td align="center">101</td>
						<td align="center"><i class="nao-ativo"></i>não</td>
						<td align="center"><a href="" class="btn alterar">ALTERAR</a><a href="" class="btn excluir">excluir</a></td>
					  </tr>
					  
					  <tr>
						<td align="left">4</td>
						<td align="left">Primeiro Produto</td>
						<td align="center">101</td>
						<td align="center"><i class="nao-ativo"></i>não</td>
						<td align="center"><a href="" class="btn alterar">ALTERAR</a><a href="" class="btn excluir">excluir</a></td>
					  </tr>
				  </tbody>
				</table>
			</div>
			<div class="base-pag">
				<p>Mostrando de 1 até 10 de 26 registros</p>
				<ul class="paginacao">
					<li><a href="" class="anterior">Anterior</a></li>
					<li><a href="">1</a></li>
					<li><a href="">2</a></li>
					<li><a href="">3</a></li>
					<li><a href="">[...]</a></li>
					<li><a href="" class="proximo">Próximo</a></li>
				</ul>
		</div>
		</div>
	</div>
</div>

