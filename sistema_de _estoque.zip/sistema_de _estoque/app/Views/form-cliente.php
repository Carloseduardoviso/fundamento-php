	<div class="conteudo">
	<div class="base-geral">
	<h1 class="titulo"><span>Cadastro de cliente </span></h1>
		<div class="base-home">
			<div class="base-form">
				<h2>preencha os campos do cadastro abaixo</h2>
				<form action="" name="">
				<div class="caixa100">
					<div class="marcacao">
						<h3>Dados pessoais</h3>
						<span>Nome</span>						
						<input type="text" placeholder="Digite o nome do cliente">	
						<span>Bairro</span>						
						<input type="text" placeholder="Digite seu endereço">
						
						<span>cidade</span>						
						<input type="text" placeholder="Digite seu endereço">
					
						<div class="separa">
						<span>CEP</span>						
						<input type="text" placeholder="Digite seu cep">						
						</div>
						<div class="separa">	
						<span>CPF</span>		
						<input type="text" placeholder="Digite seu CPF">						
						</div>
						<div class="separa">
						<span>RG</span>						
						<input type="text" placeholder="Digite um RG">						
						</div>
						<div class="separa">	
						<span>UF</span>		
						<input type="text" placeholder="Digite seu estado">						
						</div>
					</div>
				
					
					<div class="marcacao">
						<h3>Dados complementares</h3>
						<span>Email</span>
						<input type="text" placeholder="Digite o seu email">
						
						<div class="separa">
						<span>Telefone</span>						
						<input type="text" placeholder="Digite seu telefone">						
						</div>
						<div class="separa">	
						<span>Celular</span>		
						<input type="text" placeholder="Digite seu celular">						
						</div>
												
					</div>
				
				<div class="basse-botoes">									
						<button class="btn cancelar">cancelar</button>
						<button class="btn finalizar">Concluir cadastro</button>
					</div>
			</div>
			</form>
		</div>
		</div>
	</div>
</div>
