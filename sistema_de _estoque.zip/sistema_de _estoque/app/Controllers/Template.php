<?php

namespace App\Controllers;

class Template extends BaseController
{
    public function index()
    {
        return view('template');
    }
}
